﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-6VUQ1VB\SQLEXPRESS;Database=FootballersExam;Trusted_Connection=True";
    }
}
