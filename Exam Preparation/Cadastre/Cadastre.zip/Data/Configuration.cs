﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-6VUQ1VB\SQLEXPRESS;Database=Cadastre;Integrated Security=True;Encrypt=False";

    }
}
