﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoices.Data.Models.Enums
{
    public enum CategoryType
    {
        ADR,
        Filters,
        Lights,
        Others,
        Tyres,
    }
}
