﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-6VUQ1VB\SQLEXPRESS;Database=Invoices;Integrated Security=True;Encrypt=False";
    }
}
