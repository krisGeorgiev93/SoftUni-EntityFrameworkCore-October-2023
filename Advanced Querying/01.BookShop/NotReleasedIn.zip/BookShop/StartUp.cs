﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);
                   

        }

        //problem 04
        public static string GetBooksByPrice(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();

            var booksByPrice = context.Books
                .Where(p => p.Price > 40)
                .Select(b => new
                {
                    b.Title,
                    b.Price
                })
                .OrderByDescending(p => p.Price)
                .ToArray();

            foreach (var book in booksByPrice)
            {
                sb.AppendLine($"{book.Title} - ${book.Price:f2}");
            }
            return sb.ToString().TrimEnd();
        }

        //problem 05
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
           
            StringBuilder stringBuilder = new StringBuilder();

            var booksNotReleasedInThisYear = context.Books
                .Where(b => b.ReleaseDate.Value.Year != year)
                .OrderBy(b => b.BookId)
                .Select(b => new
                {
                    b.Title
                });

            foreach (var book in booksNotReleasedInThisYear)
            {
                stringBuilder.AppendLine(book.Title);
            }         

            return stringBuilder.ToString().TrimEnd();          

        }







    }
}


