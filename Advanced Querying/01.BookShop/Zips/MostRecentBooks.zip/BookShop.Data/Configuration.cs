﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-6VUQ1VB\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
