﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-6VUQ1VB\SQLEXPRESS;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
